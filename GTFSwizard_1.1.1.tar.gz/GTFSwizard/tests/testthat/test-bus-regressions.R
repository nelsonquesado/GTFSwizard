test_that("Fortaleza bus feed remains warning-free in spatial workflows", {
  skip_on_cran()

  expect_no_warning(shapes <- get_shapes_sf(for_bus_gtfs))
  expect_true(all(is.na(shapes$shapes$shape_dist_traveled)))
  expect_false(any(is.infinite(shapes$shapes$shape_dist_traveled)))

  expect_no_warning(system_plot <- plot(for_bus_gtfs))
  expect_s3_class(system_plot, "ggplot")
  expect_no_warning(route_plot <- plot_routefrequency(for_bus_gtfs))
  expect_equal(route_plot$theme$legend.position, "none")
  expect_no_warning(hubs <- plot_hubs(for_bus_gtfs))
  expect_lte(nrow(hubs$layers[[2]]$data), 40)
  expect_gt(max(hubs$layers[[2]]$data$n_routes), 1)
  expect_no_warning(corridors <- plot_corridor(for_bus_gtfs))
  expect_s3_class(corridors, "ggplot")
  expect_no_warning(app <- explore_gtfs(for_bus_gtfs))
  expect_s3_class(app, "shiny.appobj")
})

test_that("Fortaleza bus feed supports partial filters and grouped selection", {
  skip_on_cran()

  stop <- for_bus_gtfs$stops$stop_id[1]
  partial <- filter_stop(for_bus_gtfs, stop)
  expect_true(nrow(partial$stop_times) > 0)
  expect_equal(unique(partial$stop_times$stop_id), stop)
  expect_true(all(partial$stop_times$trip_id %in% partial$trips$trip_id))

  grouped <- selection(
    for_bus_gtfs,
    route_id,
    direction_id,
    route_id %in% for_bus_gtfs$routes$route_id[1:3]
  )
  info <- attr(grouped, "selection")
  expect_equal(info$group_vars, c("route_id", "direction_id"))
  expect_true(all(info$routes %in% for_bus_gtfs$routes$route_id[1:3]))
  expect_true(nrow(info$groups) >= 3)
})

test_that("service pattern notation remains stable for the bus feed", {
  skip_on_cran()

  patterns <- get_servicepattern(for_bus_gtfs)
  expect_true(all(grepl("^servicepattern-[0-9]+$", patterns$service_pattern)))
  expect_identical(
    as.character(patterns$service_pattern),
    paste0("servicepattern-", seq_len(nrow(patterns)))
  )
})
