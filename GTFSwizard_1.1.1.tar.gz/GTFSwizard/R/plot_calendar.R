#' Plot the GTFS Service Calendar
#'
#' Creates a calendar heatmap of scheduled trips by service date.
#'
#' @param gtfs A GTFS object.
#' @param ncol Number of facet columns when `facet_by_year = FALSE`.
#' @param facet_by_year Logical. Arrange years in rows and months in columns.
#'
#' @return A `ggplot` object.
#'
#' @examples
#' plot_calendar(for_rail_gtfs, ncol = 4)
#'
#' @seealso [GTFSwizard::get_servicepattern()]
#' @export
plot_calendar <- function(gtfs, ncol = 6, facet_by_year = FALSE){
  gtfs <- ensure_wizardgtfs(gtfs)
  checkmate::assert_int(ncol, lower = 1L)
  checkmate::assert_flag(facet_by_year)
  colors <- gtfswizard_colors()

  trips_per_service <- gtfs$trips |>
    dplyr::count(service_id, name = "trips")
  counts <- tidyr::unnest(gtfs$dates_services, cols = "service_id") |>
    dplyr::left_join(trips_per_service, by = "service_id") |>
    dplyr::group_by(date) |>
    dplyr::summarise(count = sum(trips, na.rm = TRUE), .groups = "drop")
  all_dates <- tibble::tibble(
    date = seq(min(gtfs$dates_services$date), max(gtfs$dates_services$date), by = "day")
  )
  data <- dplyr::left_join(all_dates, counts, by = "date")
  weekday_number <- as.integer(format(data$date, "%w"))
  first <- as.Date(format(data$date, "%Y-%m-01"))
  data$weekday <- factor(
    weekday_number,
    levels = 0:6,
    labels = c("Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat")
  )
  data$day_of_month <- as.integer(format(data$date, "%d"))
  data$month <- factor(
    format(data$date, "%B"), levels = month.name
  )
  data$year <- format(data$date, "%Y")
  data$week_of_month <- (
    data$day_of_month - 1L + as.integer(format(first, "%w"))
  ) %/% 7L + 1L

  plot <- ggplot2::ggplot(
    data, ggplot2::aes(weekday, -week_of_month)
  ) +
    ggplot2::geom_tile(
      ggplot2::aes(fill = count),
      color = "white", linewidth = 0.4
    ) +
    ggplot2::geom_text(
      ggplot2::aes(label = day_of_month),
      size = 2.8, color = colors[["ink"]]
    ) +
    ggplot2::scale_fill_gradient(
      low = "#DCEBE8", high = colors[["teal"]], na.value = "#F0F2F3"
    ) +
    ggplot2::labs(
      title = "Scheduled Service Calendar",
      subtitle = "Trip count by service date",
      x = NULL, y = NULL, fill = "Trips"
    ) +
    theme_gtfswizard() +
    ggplot2::theme(
      axis.text.y = ggplot2::element_blank(),
      axis.ticks = ggplot2::element_blank(),
      panel.grid = ggplot2::element_blank(),
      panel.spacing = grid::unit(8, "pt")
    )
  if(facet_by_year){
    plot + ggplot2::facet_grid(year ~ month)
  } else {
    plot + ggplot2::facet_wrap(
      ggplot2::vars(year, month), ncol = ncol
    )
  }
}
